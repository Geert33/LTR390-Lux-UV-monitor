# LTR390

Arduino library for the LTR390 UV sensors. Support calculation of Lux and UV Index.

